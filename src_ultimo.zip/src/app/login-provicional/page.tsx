// src/app/login/page.tsx
"use client";

import { useState } from "react";
import { useClienteAuth } from "@/hooks/useClienteAuth";

export default function LoginPage() {
  const { cliente, login, logout, loading } = useClienteAuth();
  const [correo, setCorreo] = useState("");
  const [telefono, setTelefono] = useState("");
  const [nombre, setNombre] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(correo, telefono, nombre);
  };

  if (loading) return <p className="p-6 text-gray-500">Cargando...</p>;

  if (cliente) {
    return (
      <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-xl shadow-md">
        <h2 className="text-2xl font-bold mb-4">👋 Hola, {cliente.nombre}</h2>
        <p className="text-gray-600 mb-2">Correo: {cliente.correo}</p>
        <p className="text-gray-600 mb-4">Teléfono: {cliente.telefono}</p>
        <button
          onClick={logout}
          className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
        >
          Cerrar sesión
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-xl shadow-md">
      <h2 className="text-2xl font-semibold mb-4 text-center">
        Iniciar sesión / Registrarse
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Nombre (opcional)"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          className="w-full border border-gray-300 rounded-md px-3 py-2"
        />
        <input
          type="email"
          placeholder="Correo"
          value={correo}
          onChange={(e) => setCorreo(e.target.value)}
          required
          className="w-full border border-gray-300 rounded-md px-3 py-2"
        />
        <input
          type="text"
          placeholder="Teléfono"
          value={telefono}
          onChange={(e) => setTelefono(e.target.value)}
          required
          className="w-full border border-gray-300 rounded-md px-3 py-2"
        />
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
        >
          {loading ? "Procesando..." : "Continuar"}
        </button>
      </form>
    </div>
  );
}
