import Ordenamiento from "./ordenamiento";


export default function Page() {
  return <Ordenamiento />;
}

