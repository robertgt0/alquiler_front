// src/lib/login.ts
import { fetchFromApi } from "./data-fetcher";

export interface ClienteAuthResponse {
  token: string;
  cliente: {
    id: string;
    nombre: string;
    correo: string;
    telefono: string;
  };
}

/**
 * Registra o inicia sesión de un cliente provisional.
 */
export async function loginCliente(
  correo: string,
  telefono: string,
  nombre?: string
): Promise<ClienteAuthResponse | null> {
  try {
    const body = { correo, telefono, nombre };
    const data = await fetchFromApi<ClienteAuthResponse>("/clientes/auth", {
      method: "POST",
      body: JSON.stringify(body),
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (data?.token) {
      // Guardar token en localStorage
      localStorage.setItem("cliente_token", data.token);
      localStorage.setItem("cliente_info", JSON.stringify(data.cliente));
    }

    return data;
  } catch (error) {
    console.error("❌ Error en loginCliente:", error);
    return null;
  }
}

/**
 * Obtiene la información del cliente autenticado desde localStorage.
 */
export function getClienteAuth() {
  if (typeof window === "undefined") return null;
  const token = localStorage.getItem("cliente_token");
  const cliente = localStorage.getItem("cliente_info");

  if (!token || !cliente) return null;

  try {
    return {
      token,
      cliente: JSON.parse(cliente),
    };
  } catch {
    return null;
  }
}

/**
 * Cierra sesión del cliente.
 */
export function logoutCliente() {
  localStorage.removeItem("cliente_token");
  localStorage.removeItem("cliente_info");
}
