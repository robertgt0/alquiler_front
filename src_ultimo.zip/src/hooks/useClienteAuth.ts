// src/hooks/useClienteAuth.ts
"use client";

import { useEffect, useState } from "react";
import {
  loginCliente,
  getClienteAuth,
  logoutCliente,
  ClienteAuthResponse,
} from "@/lib/login";

export function useClienteAuth() {
  const [cliente, setCliente] = useState<ClienteAuthResponse["cliente"] | null>(
    null
  );
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = getClienteAuth();
    if (auth) {
      setCliente(auth.cliente);
      setToken(auth.token);
    }
    setLoading(false);
  }, []);

  async function login(correo: string, telefono: string, nombre?: string) {
    setLoading(true);
    const res = await loginCliente(correo, telefono, nombre);
    if (res) {
      setCliente(res.cliente);
      setToken(res.token);
    }
    setLoading(false);
    return res;
  }

  function logout() {
    logoutCliente();
    setCliente(null);
    setToken(null);
  }

  return { cliente, token, loading, login, logout };
}
