// src/app/epic_example/citas-agendadas/page.tsx
"use client";

import React from "react";
import CitasAgendadas from "../components/CitasAgendadas";

export default function Page() {
  return <CitasAgendadas />;
}
