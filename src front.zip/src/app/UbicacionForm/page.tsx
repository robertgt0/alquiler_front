'use client';

import UbicacionForm from "@/Features/UbicacionForm/UbicacionForm";

export default function Page() {
  return <UbicacionForm />;
}
